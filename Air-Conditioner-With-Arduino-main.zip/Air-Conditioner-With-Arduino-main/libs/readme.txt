++++++++++++++++++++++++++++++++++

    INSTALL THE LIBRARIES

++++++++++++++++++++++++++++++++++

install all the libraries in these folder in your Arduino IDE before using any code for controlling your air conditioner.
download all the zip files and install the them in the Arduino IDE.
