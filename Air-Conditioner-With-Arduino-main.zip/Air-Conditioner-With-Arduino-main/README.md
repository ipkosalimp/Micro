# Air-Conditioner-With-Arduino
In this repository, you will find all the projects about how to control an Air Conditioner using Arduino. All the codes, the circuits, the libraries and diagrams are available.

you can also watch all the videos on my youtube channel: 
https://www.youtube.com/channel/UCxfcL14qry5Z8C795zb3pbQ
