#ifndef DYIRDaikinPWM_h
#define DYIRDaikinPWM_h

// include  Arduino-IRremote PWM declare to keep compatibility
// hardware specification goto https://github.com/z3t0/Arduino-IRremote/blob/master/README.md
// All board specific stuff has been moved to its own file, included here.
#include "boarddefs.h"
//
#endif

